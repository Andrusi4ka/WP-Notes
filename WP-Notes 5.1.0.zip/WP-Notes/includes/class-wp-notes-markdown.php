<?php

if (! defined('ABSPATH')) {
	exit;
}

class WP_Notes_Markdown {
	public static function convert($html) {
		$html = (string) $html;

		if ('' === trim($html)) {
			return '';
		}

		$dom = new DOMDocument();
		libxml_use_internal_errors(true);
		$dom->loadHTML(
			'<?xml encoding="utf-8" ?><div id="wp-notes-md-root">' . $html . '</div>',
			LIBXML_NOERROR | LIBXML_NOWARNING | LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD
		);
		libxml_clear_errors();

		$xpath = new DOMXPath($dom);
		$nodes = $xpath->query('//*[@id="wp-notes-md-root"]');

		if (! $nodes || ! $nodes->length) {
			return '';
		}

		$root   = $nodes->item(0);
		$blocks = array();

		foreach ($root->childNodes as $child) {
			$block = trim(self::render_block($child));
			if ('' !== $block) {
				$blocks[] = $block;
			}
		}

		return '' === implode('', $blocks) ? '' : trim(implode("\n\n", $blocks)) . "\n";
	}

	private static function render_block($node) {
		if (XML_TEXT_NODE === $node->nodeType) {
			return trim(preg_replace('/\s+/', ' ', $node->nodeValue));
		}

		if (XML_ELEMENT_NODE !== $node->nodeType) {
			return '';
		}

		switch (strtolower($node->tagName)) {
			case 'h1':
				return '# ' . trim(self::render_inline_children($node));
			case 'h2':
				return '## ' . trim(self::render_inline_children($node));
			case 'h3':
				return '### ' . trim(self::render_inline_children($node));
			case 'blockquote':
				return self::render_blockquote($node);
			case 'pre':
				return self::render_code_block($node);
			case 'hr':
				return '---';
			case 'ol':
				return self::render_list($node, true);
			case 'ul':
				return self::render_list($node, false);
			default:
				return trim(self::render_inline_children($node));
		}
	}

	private static function render_blockquote($node) {
		$inner = trim(self::render_inline_children($node));
		$lines = explode("\n", $inner);
		$out   = array();

		foreach ($lines as $line) {
			$out[] = '' === $line ? '>' : '> ' . $line;
		}

		return implode("\n", $out);
	}

	private static function render_code_block($node) {
		$text = rtrim((string) $node->textContent, "\n");

		return "```\n" . $text . "\n```";
	}

	private static function render_list($node, $ordered) {
		$items = array();
		$index = 1;

		foreach ($node->childNodes as $child) {
			if (XML_ELEMENT_NODE !== $child->nodeType || 'li' !== strtolower($child->tagName)) {
				continue;
			}

			$content = trim(self::render_inline_children($child));
			$content = str_replace("\n", "\n  ", $content);
			$prefix  = $ordered ? ($index . '. ') : '- ';
			$items[] = $prefix . $content;
			$index++;
		}

		return implode("\n", $items);
	}

	private static function render_inline_children($node) {
		$out = '';

		foreach ($node->childNodes as $child) {
			$out .= self::render_inline($child);
		}

		return $out;
	}

	private static function render_inline($node) {
		if (XML_TEXT_NODE === $node->nodeType) {
			return preg_replace('/\s+/', ' ', $node->nodeValue);
		}

		if (XML_ELEMENT_NODE !== $node->nodeType) {
			return '';
		}

		$tag = strtolower($node->tagName);

		switch ($tag) {
			case 'br':
				return "\n";
			case 'strong':
			case 'b':
				$inner = trim(self::render_inline_children($node));
				return '' === $inner ? '' : '**' . $inner . '**';
			case 'em':
			case 'i':
				$inner = trim(self::render_inline_children($node));
				return '' === $inner ? '' : '*' . $inner . '*';
			case 's':
			case 'strike':
			case 'del':
				$inner = trim(self::render_inline_children($node));
				return '' === $inner ? '' : '~~' . $inner . '~~';
			case 'code':
				$inner = trim((string) $node->textContent);
				return '' === $inner ? '' : '`' . $inner . '`';
			case 'a':
				$href  = $node->getAttribute('href');
				$inner = trim(self::render_inline_children($node));
				if ('' === $inner) {
					$inner = $href;
				}
				return '' === $href ? $inner : '[' . $inner . '](' . $href . ')';
			case 'img':
				$src = $node->getAttribute('src');
				$alt = $node->getAttribute('alt');
				return '' === $src ? '' : '![' . $alt . '](' . $src . ')';
			case 'h1':
			case 'h2':
			case 'h3':
			case 'p':
			case 'div':
			case 'blockquote':
			case 'pre':
			case 'ol':
			case 'ul':
				$block = trim(self::render_block($node));
				return '' === $block ? '' : "\n\n" . $block . "\n\n";
			default:
				return self::render_inline_children($node);
		}
	}
}
